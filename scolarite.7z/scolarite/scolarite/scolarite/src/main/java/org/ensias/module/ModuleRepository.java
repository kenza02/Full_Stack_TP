package org.ensias.module;

import org.springframework.data.repository.CrudRepository;
public interface ModuleRepository extends CrudRepository<MyModule, Integer> {
}
