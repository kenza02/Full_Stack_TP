package org.ensias.module;

import org.ensias.module.MyModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Optional;

@Service
public class ModuleService {
    //private List<MyModule> modules= new ArrayList<>(Arrays.asList(new MyModule(10 ,"Java SE", "Description de la plateforme Java SE"), new MyModule(12, "Java EE", "Description de la plateforme Java EE")));
    @Autowired
    private ModuleRepository moduleRepository;
    public List<MyModule> getAllModules() {
        List<MyModule> modules=new ArrayList<>();
        //moduleRepository.findAll().forEach(modules::add);
        moduleRepository.findAll().forEach(m->modules.add(m));
        return modules;
    }

    public Optional<MyModule> getModule(Integer id) {
        return moduleRepository.findById(id);
    }

    public void ajouterModule(MyModule module) {
        moduleRepository.save(module);
    }
    public void modifierModule(Integer id, MyModule module) {
        moduleRepository.save(module);
    }

    public void supprimerModule(Integer id) {
        moduleRepository.deleteById(id);
    }

}