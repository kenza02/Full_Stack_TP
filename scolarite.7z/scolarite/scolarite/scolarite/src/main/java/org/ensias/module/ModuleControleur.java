package org.ensias.module;
import org.ensias.module.MyModule;
import org.ensias.module.ModuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@RestController
public class ModuleControleur {
    @Autowired
    private ModuleService moduleService;
    @RequestMapping("/modules")
    public List<MyModule> getModules() {
        return moduleService.getAllModules();
    }

    @RequestMapping("/modules/{id}")
    public Optional<MyModule> getModule(@PathVariable Integer id){
        return moduleService.getModule(id);
    }

    @RequestMapping(method=RequestMethod.POST, value="/modules")
    public void ajouterModule(@RequestBody MyModule module) {
        moduleService.ajouterModule(module);
    }

    @RequestMapping(method=RequestMethod.PUT, value="/modules/{id}")
    public void modifierModule(@RequestBody MyModule module, @PathVariable Integer id) {
        moduleService.modifierModule(id, module);
    }

    @RequestMapping(method=RequestMethod.DELETE, value="/modules/{id}")
    public void supprimerModule(@PathVariable Integer id) {
        moduleService.supprimerModule(id);
    }

}
