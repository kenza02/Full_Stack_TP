package org.ensias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScolariteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScolariteApplication.class, args);
	}

}
