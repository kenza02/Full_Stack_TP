package org.ensias.scolarite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScolariteApplicationTests {

	@Test
	void contextLoads() {
	}

}
